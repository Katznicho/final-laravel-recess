
<style>
.sidebar{
    background:#000 !important;
    color:#fff;
}
ul->li->a:hover{
    color: red !important;


}
</style>
<div class="sidebar">
    <div class="sidebar-wrapper">
        <div class="logo">
            <h2><?php echo e(Auth::user()->name); ?></h2>
        </div>
        <?php if(Auth::user()->role != 'Director'): ?>
        <ul class="nav">
            <li >
                <a href="<?php echo e(route('home')); ?>">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li >
                <a href="<?php echo e(route('treasury')); ?>">
                    <i class="tim-icons icon-coins"></i>
                    <p><?php echo e(__('Treasury')); ?></p>
                </a>
            </li>
            <li >
                <a href="<?php echo e(route('donorlist')); ?>">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p><?php echo e(__('DonorList')); ?></p>
                </a>
            </li>

            
            <li>
                <a data-toggle="collapse" href="#laravel-examples" aria-expanded="true">
                    <i class="tim-icons icon-key-25" ></i>
                    <span class="nav-link-text" >REGISTER</span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse show" id="laravel-examples">
                    <ul class="nav pl-4">
                        <li>
                            <a href="<?php echo e(route('registerofficer')); ?>">
                                <i class="tim-icons icon-single-02"></i>
                             <p><?php echo e(__('HealthOfficer')); ?></p>
                            </a>
                        </li>
                        <li   >
                            <a href="<?php echo e(route('donations')); ?>">
                                <i class="tim-icons icon-coins"></i>
                            <p><?php echo e(__('DonorMoney')); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
                
                <a data-toggle="collapse" href="#charts" aria-expanded="false">
                    <i class="tim-icons icon-chart-bar-32" ></i>
                    <span class="nav-link-text" >CHARTS</span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse show" id="charts">
                    <ul class="nav pl-4">
                        <li>
                            <a href="<?php echo e(route("donation")); ?>">
                                <i class="tim-icons icon-money-coins"></i>
                             <p><?php echo e(__('DonationGraph')); ?></p>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route("donation")); ?>">
                                <i class="tim-icons icon-money-coins"></i>
                             <p><?php echo e(__('MonthsGraphs')); ?></p>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route("wellwishers")); ?>">
                                <i class="tim-icons icon-money-coins"></i>
                             <p><?php echo e(__('WellWishersGraphs')); ?></p>
                            </a>
                        </li>
                        <li  >
                            <a href="<?php echo e(route('donations')); ?>">
                                <i class="tim-icons icon-pin"></i>
                                <p><?php echo e(__('PercentageGraph')); ?></p>
                            </a>
                        </li>
                        <li  >
                            <a href="<?php echo e(route('hierarchical')); ?>">
                                <i class="tim-icons icon-triangle-right-17"></i>
                                <p><?php echo e(__('HierarchicalGraph')); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
                


            </li>
            
           
            <li>
                <a href="<?php echo e(route('patientlist')); ?>">
                    <i class="tim-icons icon-single-copy-04"></i>
                    <p><?php echo e(__('PatientList')); ?></p>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route("promotions")); ?>">
                    <i class="tim-icons icon-single-copy-04"></i>
                    <p><?php echo e(__("Promotionns")); ?></p>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route("waitinglist")); ?>">
                    <i class="tim-icons icon-single-copy-04"></i>
                    <p><?php echo e(__('WaitingList')); ?></p>
                </a>
            </li>
            
           
        
        </ul>


            
        <?php else: ?>
        <ul class="nav">
            <li >
                <a href="<?php echo e(route('donorlist')); ?>">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p><?php echo e(__('DonorList')); ?></p>
                </a>
            </li>
            
            <li >
                <a href="<?php echo e(route('treasury')); ?>">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p><?php echo e(__('Treasury')); ?></p>
                </a>
            </li>
            
            <li>

                <a data-toggle="collapse" href="#charts" aria-expanded="true">
                    <i class="tim-icons icon-chart-bar-32" ></i>
                    <span class="nav-link-text" >CHARTS</span>
                    <b class="caret mt-1"></b>
                </a>

                <div class="collapse show" id="charts">
                    <ul class="nav pl-4">
                        <li>
                            <a href="<?php echo e(route("donation")); ?>">
                                <i class="tim-icons icon-money-coins"></i>
                             <p><?php echo e(__('MonthsGraphs')); ?></p>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route("wellwishers")); ?>">
                                <i class="tim-icons icon-money-coins"></i>
                             <p><?php echo e(__('WellWishersGraphs')); ?></p>
                            </a>
                        </li>
                        <li  >
                            <a href="<?php echo e(route('donations')); ?>">
                                <i class="tim-icons icon-pin"></i>
                                <p><?php echo e(__('PercentageGraph')); ?></p>
                            </a>
                        </li>
                        <li  >
                            <a href="<?php echo e(route('hierarchical')); ?>">
                                <i class="tim-icons icon-triangle-right-17"></i>
                                <p><?php echo e(__('HierarchicalGraph')); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
                


            </li>
           
            <li>
                <a href="<?php echo e(route('patientlist')); ?>">
                    <i class="tim-icons icon-single-copy-04"></i>
                    <p><?php echo e(__('PatientList')); ?></p>
                </a>
            </li>
            
            <li >
                <a href="<?php echo e(route('donorlist')); ?>">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p><?php echo e(__('DonorList')); ?></p>
                </a>
            </li>
        
        </ul>

            
        <?php endif; ?>
            </div>
</div>
<?php /**PATH /home/katende/Desktop/final-project/resources/views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>