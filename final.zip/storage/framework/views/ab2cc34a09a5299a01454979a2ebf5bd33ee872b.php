<style>
    .make-fixed{
        position:sticky !important;
        top:0 !important;
        z-index: 100 !important;

    }
    nav.navbar.navbar-expand-lg.navbar-absolute.navbar-transparent{
        background:#1c478e !important;
        color:#fff;
        position:sticky !important;
        top:0 !important;
        z-index: 100 !important;

    }
</style>
<div class="make-fixed">
    <nav class="navbar navbar-expand-lg navbar-absolute navbar-transparent">
        <div class="container-fluid ">
            <div class="navbar-wrapper d-none">
                <div class="navbar-toggle d-inline">
                    <button type="button" class="navbar-toggler">
                        <span class="navbar-toggler-bar bar1"></span>
                        <span class="navbar-toggler-bar bar2"></span>
                        <span class="navbar-toggler-bar bar3"></span>
                    </button>
                </div>
                <a class="navbar-brand" href="#"><?php echo e($page ?? __('Dashboard')); ?></a>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-bar navbar-kebab"></span>
                <span class="navbar-toggler-bar navbar-kebab"></span>
                <span class="navbar-toggler-bar navbar-kebab"></span>
            </button>
            <div class="collapse navbar-collapse" id="navigation">
                <div class="mr-auto">
                    <h4>COVID 19 MANAGEMENT SYSTEM</h4>
                </div>
                <ul class="navbar-nav ml-auto">
                    
                       
                     <li class="dropdown nav-item">
                        <a href="javascript:void(0)" class="dropdown-toggle nav-link" data-toggle="dropdown">
                          <div class="notification d-none d-lg-block d-xl-block"></div>
                          <i class="tim-icons icon-bell-55"><sup>2</sup></i>
                          <p class="d-lg-none">
                            Notifications
                          </p>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right dropdown-navbar">
                          <li class="nav-link"><a href="#" class="nav-item dropdown-item">Mike John responded to your email</a></li>
                          <li class="nav-link"><a href="javascript:void(0)" class="nav-item dropdown-item">You have 5 more tasks</a></li>
                          <li class="nav-link"><a href="javascript:void(0)" class="nav-item dropdown-item">Your friend Michael is in town</a></li>
                          <li class="nav-link"><a href="javascript:void(0)" class="nav-item dropdown-item">Another notification</a></li>
                          <li class="nav-link"><a href="javascript:void(0)" class="nav-item dropdown-item">Another one</a></li>
                        </ul>
                      </li>  
                                   

                    <li class="dropdown nav-item">
                        <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                            
                            <b class="caret d-none d-lg-block d-xl-block"></b>
                            <p class="d-lg-none"><?php echo e(__('Log out')); ?></p>
                        </a>
                        <ul class="dropdown-menu dropdown-navbar">
                            
                            <li class="nav-link">
                                <a href="<?php echo e(route('logout')); ?>" class="nav-item dropdown-item" 
                                onclick="event.preventDefault();  
                                document.getElementById('logout-form').submit();"><?php echo e(__('Log out')); ?></a>
                            </li>
                        </ul>
                    </li>
                    <li class="separator d-lg-none"></li>
                </ul>
            </div>
        </div>
    </nav>
    
    </div>
<?php /**PATH /home/katende/Desktop/final-project/resources/views/layouts/navbars/navs/auth.blade.php ENDPATH**/ ?>