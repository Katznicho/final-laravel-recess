<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HierarchicalController extends Controller
{
    //
    public function index(){
        return view("chart.hierarchical");
    }
}
