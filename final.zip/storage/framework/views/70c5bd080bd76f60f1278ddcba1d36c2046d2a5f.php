<?php $__env->startSection('content'); ?>
<style>
    .tab{
        text-align: center;
        background:#000;
        color:#fff;
        border-radius: 999px;
        width: 100%;
        padding: 8px;
        font-weight: 800;
    }
    /* .color{
      background: red;
      width: 20%;
      height: 20px;
      align-self: center;
      align-items: center;
      text-align: center;

    } */
</style>
    <div class="header ">
        <div class="container">
            <div class="header-body text-center ">
                <div class="">
                        

                         <form method="POST" action="<?php echo e(route('money')); ?>" class="m-2">
                            <?php echo csrf_field(); ?>
                        
                            <div class="form-group  ">
                              <div class="form-group row">
                                <label for="role" class="label"><?php echo e(__('SelectMonth')); ?></label>
                                <div class="col-md-12">
                                    <select name="month" id="" class="form-control">
                                      <?php if(count($months)): ?>
                                      <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value=<?php echo e($month->Month); ?>><?php echo e($month->Month); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php endif; ?>
                                      
                        
                                    </select>
                                    
                                    <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                                </div>
                            </div>
                            <div class="form-group ml-6 mt-2 d-flex flex-column">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('SelectMonth')); ?>

                                    </button>
                                
                            </div>
                        </form> 
                            
                         
                
                    
                    <div class="col-md-12">
                       <div class="tab md-12 mb-3">
    
                             MonthlySalary 
                             <?php if($default): ?>
                                 <b><?php echo e($default); ?></b>
                             <?php endif; ?>
                         
                       </div>
                       <div class="card">
                        <div class="card-header card-header-primary">
                          <h4 class="card-title text-center">GeneralOfficers</h4>
                        </div>
                        <?php if(count($officers_general)): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                              <table class="table">
                                <thead class=" text-primary">
                                  <th>
                                    OfficerName
                                  </th>
                                  <th>
                                    OfficerRole
                                  </th>
                                  <th>
                                    Amount
                                  </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $officers_general; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                          <?php echo e($officer->OfficerName); ?>

                                        </td>
                                        <td>
                                          <?php echo e($officer->OfficerRole); ?>

                                        </td>
                                        <td>
                                            <small
                                          style="font-weight: bold"
                                          >shs</small>
                                          <?php echo e($officer->MonthlySalary); ?>

                                        </td>
                                        
                                       
                                      </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                              </table>
                              
                            </div>
                          </div>
                            
                        <?php endif; ?>
                       
                      </div>
                    </div>
              

                       
                       <div class="card">
                        <div class="card-header card-header-primary">
                          <h4 class="card-title text-center">RegiobalOfficers</h4>
                        </div>
                        <?php if($officers_regional): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                              <table class="table">
                                <thead class=" text-primary">
                                  <th>
                                    OfficerName
                                  </th>
                                  <th>
                                    OfficerRole
                                  </th>
                                  <th>
                                    Amount
                                  </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $officers_regional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                          <?php echo e($officer->OfficerName); ?>

                                        </td>
                                        <td>
                                          <?php echo e($officer->OfficerRole); ?>

                                        </td>
                                        <td>
                                          <small
                                          style="font-weight: bold"
                                          >shs</small><?php echo e($officer->MonthlySalary); ?>

                                        </td>
                                        
                                       
                                      </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                              </table>
                              
                            </div>
                          </div>
                            
                        <?php endif; ?>
                       
                      </div>
                    </div>
              
                       
                       <div class="card">
                        <div class="card-header card-header-primary">
                          <h4 class="card-title text-center">NationalOfficers</h4>
                        </div>
                        <?php if(count($officers_general)): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                              <table class="table">
                                <thead class=" text-primary">
                                  <th>
                                    OfficerName
                                  </th>
                                  <th>
                                    OfficerRole
                                  </th>
                                  <th>
                                  Amount
                                  </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $officers_national; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                          <?php echo e($officer->OfficerName); ?>

                                        </td>
                                        <td>
                                          <?php echo e($officer->OfficerRole); ?>

                                        </td>
                                        <td>
                                            <small
                                          style="font-weight: bold"
                                          >shs</small>
                                          <?php echo e($officer->MonthlySalary); ?>

                                        </td>
                                        
                                       
                                      </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                              </table>
                              
                            </div>
                          </div>
                            
                        <?php endif; ?>
                       
                      </div>
                    </div>
              
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katende/Desktop/final-project/resources/views/welcome.blade.php ENDPATH**/ ?>