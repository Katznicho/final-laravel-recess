<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title text-center">OfficerTable</h4>
            </div>
            <?php if($officerlist): ?>
            <div class="card-body">
                <div class="">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        OfficerName
                      </th>
                      <th>
                        OfficerUserName
                      </th>
                      <th>
                        HospitalName
                      </th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $officerlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                              <?php echo e($officer->OfficerName); ?>

                            </td>
                            <td>
                              <?php echo e($officer->OfficerUserName); ?>

                            </td>
                            <td>
                              <?php echo e($officer->HospitalName); ?>

                            </td>
                            
                           
                          </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </tbody>
                  </table>
                  
                </div>
              </div>
                
            <?php endif; ?>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           
          </div>
        </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katende/Desktop/final-project/resources/views/officer_list.blade.php ENDPATH**/ ?>