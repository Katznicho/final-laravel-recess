<?php $__env->startSection('content'); ?>
<style>
    .tab{
        text-align: center;
        background:#000;
        color:#fff;
        border-radius: 999px;
        width: 100%;
        padding: 8px;
        font-weight: 800;
    }
    .tab-remain{
        text-align: center;
        background:#1c478e;
        color:#fff;
        border-radius: 999px;
        width: 100%;
        padding: 10px;
        font-weight: 900;
    }
    
</style>
    <div class="header ">
        <div class="container">
            <div class="header-body text-center ">
              <div class="tab-remain md-12 mb-3">
                <?php if($treasury_amount ?? ''): ?>
                  Amount remaining :  shs<h4><?php echo e($treasury_amount); ?><h4>
                    after <?php echo e($default?? ''); ?> payments
                <?php endif; ?>
            
          </div>
                <div class="">
                        
                                            
                    <div class="col-md-12">
                       <div class="tab md-12 mb-3">
    
                             MonthlySalary 
                             <?php if($default ?? ''): ?>
                                 <b><?php echo e($default ?? ''); ?></b> according to shs <?php echo e($payamount); ?>

                             <?php endif; ?>
                         
                       </div>

                       
                       <div class="card">
                        <div class="card-header card-header-primary">
                          <h4 class="card-title text-center">GeneralOfficers</h4>
                        </div>
                        <?php if(count($officers_general)): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                              <table class="table">
                                <thead class=" text-primary">
                                  <th>
                                    OfficerName
                                  </th>
                                  <th>
                                    OfficerRole
                                  </th>
                                  <th>
                                    Amount
                                  </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $officers_general; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                          <?php echo e($officer->OfficerName); ?>

                                        </td>
                                        <td>
                                          <?php echo e($officer->OfficerRole); ?>

                                        </td>
                                        <td>
                                            <small
                                          style="font-weight: bold"
                                          >shs</small>
                                          <?php echo e($officer->MonthlySalary); ?>

                                        </td>
                                        
                                       
                                      </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                              </table>
                              
                            </div>
                          </div>
                            
                        <?php endif; ?>
                       
                      </div>
                    </div>
              
                      


                       <div class="card">
                        <div class="card-header card-header-primary">
                          <h4 class="card-title text-center">StaffOfficers</h4>
                        </div>
                        <?php if(count($staff)): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                              <table class="table">
                                <thead class=" text-primary">
                                  <th>
                                    StaffName
                                  </th>
                                  <th>
                                    OfficerRole
                                  </th>
                                  <th>
                                  Amount
                                  </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                          <?php echo e($officer->name); ?>

                                        </td>
                                        <td>
                                          <?php echo e($officer->role); ?>

                                        </td>
                                        <td>
                                            <small
                                          style="font-weight: bold"
                                          >shs</small>
                                          <?php echo e($officer->monthlysalary); ?>

                                        </td>
                                        
                                       
                                      </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                              </table>
                              
                            </div>
                          </div>
                            
                        <?php endif; ?>

                       
                      </div>
                          
                       
                       <div class="card">
                        <div class="card-header card-header-primary">
                          <h4 class="card-title text-center">RegiobalOfficers</h4>
                        </div>
                        <?php if($officers_regional): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                              <table class="table">
                                <thead class=" text-primary">
                                  <th>
                                    OfficerName
                                  </th>
                                  <th>
                                    OfficerRole
                                  </th>
                                  <th>
                                    Amount
                                  </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $officers_regional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                          <?php echo e($officer->OfficerName); ?>

                                        </td>
                                        <td>
                                          <?php echo e($officer->OfficerRole); ?>

                                        </td>
                                        <td>
                                          <small
                                          style="font-weight: bold"
                                          >shs</small><?php echo e($officer->MonthlySalary); ?>

                                        </td>
                                        
                                       
                                      </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                              </table>
                              
                            </div>
                          </div>
                            
                        <?php endif; ?>
                       
                      </div>
                    </div>
              
                       
                       <div class="card">
                        <div class="card-header card-header-primary">
                          <h4 class="card-title text-center">NationalOfficers</h4>
                        </div>
                        <?php if(count($officers_general)): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                              <table class="table">
                                <thead class=" text-primary">
                                  <th>
                                    OfficerName
                                  </th>
                                  <th>
                                    OfficerRole
                                  </th>
                                  <th>
                                  Amount
                                  </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $officers_national; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                          <?php echo e($officer->OfficerName); ?>

                                        </td>
                                        <td>
                                          <?php echo e($officer->OfficerRole); ?>

                                        </td>
                                        <td>
                                            <small
                                          style="font-weight: bold"
                                          >shs</small>
                                          <?php echo e($officer->MonthlySalary); ?>

                                        </td>
                                        
                                       
                                      </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                              </table>
                              
                            </div>
                          </div>
                            
                        <?php endif; ?>

                       
                      </div>
                      <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

                    </div>
              
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katende/Desktop/final-project/resources/views/moneydistribution.blade.php ENDPATH**/ ?>