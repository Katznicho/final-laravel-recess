<?php $__env->startSection('content'); ?>
<style>
  .tab{
        text-align: center;
        background:#000;
        color:#fff;
        border-radius: 999px;
        width: 100%;
        padding: 8px;
        font-weight: 800;
    }
</style>

<div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php if($sum): ?>
               <div class="container">
                   <div class="tab">
                     TotalAmount  :  shs 
                     <?php echo e('   '. $sum); ?>

                   </div>
               </div>
                  
              <?php endif; ?>
          <div class="card">
          <div class="col-md-12">
            <div class="card">
              
              <div class="card-header card-header-primary">
                <h4 class="card-title text-center">TotalAmountMonthly  greater
                  than shs<?php echo e(number_format(50000000,2)); ?>

                </h4>
              </div>
              <?php if(count($Amount)): ?>
              <div class="card-body">
                  <div class="">
                    <table class="table">
                      <thead class=" text-primary">
                        <th>
                          Month
                        </th>
                        <th>
                          TotalAmount
                        </th>
                        <th>
                          PayableAmount
                        </th>
                        <td>
                          Payments
                        </td>
                        <td>
                          ViewPayments
                        </td>
                       
                      </thead>
                      <tbody>
                          <?php $__currentLoopData = $Amount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td>
                                <?php echo e($donor->Month); ?>

                              </td>
                              <td>
                                shs<?php echo e($donor->Amount); ?>

                              </td>
                              <td>


                                 <?php if((int)$donor->Amount < ((int)100000000)): ?>
                                     0
                                 <?php else: ?>
                                    <?php echo e((int)$donor->Amount - (int)100000000); ?>

                                     
                                 <?php endif; ?>
                              </td>
                              <td>
                                <?php if(((int)$donor->Amount < ((int)100000000)) && !$donor->MonthPaid &&(int)$donor->Amount -(int)100000000 == 0): ?> )
                                <button type="button" 
                                class="btn btn-primary" disabled>NoPayments</button>
                                
        
                                    
                                <?php else: ?>
                                <?php if($donor->MonthPaid ): ?>
                                <button type="button" 
                                class="btn btn-primary" disabled>PaidAlready</button>

                                    
                                <?php else: ?>
                                <a type="button" href="<?php echo e(route('money', ['month'=>$donor->Month, 'amount'=>(int)$donor->Amount - ((int)100000000)

                                  ])); ?>"
                                   
                                 class="btn btn-success">MakePayment</a>
                                    
                                <?php endif; ?>


                                    
                                <?php endif; ?>


                              </td>
                              <td>
                                <?php if($donor->MonthPaid): ?>
                                    <button class="btn btn-primary">ViewPayments</button>
                                <?php endif; ?>
                              </td>
                              

  
                            </tr>
                              
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </tbody>
                    </table>
                    
                  </div>
                </div>
                  
              <?php endif; ?>
             
            </div>
          

          <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katende/Desktop/final-project/resources/views/treasury.blade.php ENDPATH**/ ?>