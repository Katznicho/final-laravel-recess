


<footer class="footer">
    <div class="container-fluid">
        
    <?php if(auth()->guard( )->check()): ?>
    <div class="d-flex justify-content-center">
        <div class="copyright mt-4 ml-1">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('made with')); ?> 
            <i class="tim-icons icon-heart-2"></i> <?php echo e(__('by')); ?>

            <small class="m-2">Group 4</small>
            <small>All Rights Reserved</small>
            <a href="<?php echo e(route('home')); ?>">BackHome</a>
            
        </div>
    </div>

</div>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
    <div class="copyright text-center align-center">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('made with')); ?> 
            <i class="tim-icons icon-heart-2"></i> <?php echo e(__('by')); ?>

            <small class="m-2">Group 4</small>
            <small>All Rights Reserved </small>
            
        </div>
    </div>
    <?php endif; ?>
    
</footer>
<?php /**PATH /home/katende/Desktop/final-project/resources/views/layouts/footer.blade.php ENDPATH**/ ?>