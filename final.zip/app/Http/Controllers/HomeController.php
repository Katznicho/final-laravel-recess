<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    //create an 
 
     
    

    //send promoted
    public function index(){
        return view("dashboard");
    }

    
     

    // public function index()
    // {
    //     //convert to an array
    //     //filter
    //      $officers_general = array();
    //      $officers_regional = array();
    //      $officers_national = array();
    //      $promotions = array();
    //     if(count($this->retrieve_officers('general'))){
    //      $converted =  $this->convert_array($this->retrieve_officers('general'));
    //     $this->filter_officers($converted);
    //      $officers_general = $this->retrieve_officers('general');
    //      //print_r($result);

    //      //retrieve regional
    //      if(count($this->retrieve_officers('regional'))){
    //          $officers_regional = $this->retrieve_officers('regional');
    //          $converted = $this->convert_array($officers_regional);
    //          $this->filter_regional_hospital($converted);

    //      }
    //      //retrieve national
    //      if(count($this->retrieve_officers('national'))){
    //         $officers_national = $this->retrieve_officers('national');
    //     }

    //     //promotions data
    //     if(count(DB::table('promotions')->get())){
    //         $promoted = DB::table('promotions')->get();
    //         $promotions = $this->format_currency($promoted->toArray());
    //         //$promoted = DB

    //     }
    //      return view('dashboard',
    //      ['officers_general'=>$officers_general,
    //         'officers_regional'=>$officers_regional,
    //         'officers_national'=>$officers_national,
    //         'promotions'=>$promotions,
    //         'currently_promoted'=>$this->promoted_to_list,
    //         'promoted_general'=>$this->promotedOfficersGeneral
            
    //         ]
    //     );
    //     }
    //     else{
            
    //         $officers_general = array();
    //         $officers_regional = array();
    //         $officers_national = array();
    //         $promotions = array();
    //         $currently_promoted =array();
    //         $general = array();
    //         $promoted = array();
    //         return view('dashboard',
    //         ['officers_general'=>$officers_general,
    //         'officers_regional'=>$officers_regional,
    //         'officers_national'=>$officers_national,
    //         'promotions'=>$promotions,
    //         'currently_promoted'=>$promoted,
    //         'promoted_general'=>$general
    //         ]
    //     );
    //     }

    // }
}
