<?php $__env->startSection('content'); ?>
<style>
  .tab{
        text-align: center;
        background:#000;
        color:#fff;
        border-radius: 999px;
        width: 100%;
        padding: 8px;
        font-weight: 800;
    }
</style>

<div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php if($sum): ?>
               <div class="container">
                   <div class="tab">
                     TotalAmount  :  shs 
                     <?php echo e('   '. $sum); ?>

                   </div>
               </div>
                  
              <?php endif; ?>
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title text-center">DonorList</h4>
            </div>
            <?php if($donorlist): ?>
            <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        DonorName
                      </th>
                      <th>
                        Amount
                      </th>
                      <th>
                        Month
                      </th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $donorlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                              <?php echo e($donor->DonorName); ?>

                            </td>
                            <td>
                              <?php echo e($donor->Amount); ?>

                            </td>
                            <td>
                              <?php echo e($donor->Month); ?>

                            </td>
                            
                           
                          </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </tbody>
                  </table>
                  
                </div>
              </div>
                
            <?php endif; ?>
           
          </div>


             


          <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katende/Desktop/final-project/resources/views/donorlist.blade.php ENDPATH**/ ?>