<?php $__env->startSection('content'); ?>
<style>
        .footer{
        margin-top: 4rem;
        padding: 10px;
        text-align: center;
    }
    .tab{
        text-align: center;
        background:#000;
        color:#fff;
        border-radius: 999px;
        width: 100%;
        padding: 8px;
        font-weight: 800;
    }
    
    .footer>a{
        text-decoration:none;

        cursor: pointer;
        font-weight: bold;
    }
    
</style>
<div class="layout">
      <!-- Chart's container -->
      <div class="">
        <div class="col-md-12 mt-3 mb-3">
          <p class="tab">GraphsDisplay</p>
      </div>


      <form method="POST" action="<?php echo e(route('donation')); ?>" class="m-2">
        <?php echo csrf_field(); ?>
    
        <div class="form-group  ">
          <div class="form-group">
            <label for="role" class="text-center"><?php echo e(__('SelectMonth')); ?></label>
            <div class="col-md-12">
                <select name="month" id="" class="form-control" 
                style="background: #000 !important; color:#fff !important">
                  <?php if(count($all_months)): ?>
                  <?php $__currentLoopData = $all_months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option 
                  style="color:#fff !important"
                  value=<?php echo e($month->Month); ?>><?php echo e($month->Month); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  
    
                </select>
                
                <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
            </div>
        </div>
        <div class="form-group ml-6 mt-2 d-flex flex-column">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('SelectMonth')); ?>

                </button>
            
        </div>
    </form> 
        

        

        <div class="">
          <div class="col-md-12 mt-3 mb-3">
            <p class="tab">A Graph of Donations in
               <?php if($selected): ?>
                 <?php echo e($selected->Month); ?>

               <?php endif; ?>
              </p> 
             

             
        </div>
        <div id="months" style="height: 800px;"></div>
          
      </div>  
      <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- Charting library -->
<script  src="https://unpkg.com/chart.js@2.9.3/dist/Chart.min.js"></script>
<!-- Chartisan -->
<script src="https://unpkg.com/@chartisan/chartjs@^2.1.0/dist/chartisan_chartjs.umd.js"></script>

 <script>
        

   const chart2 = new Chartisan({
     el: '#months',
     url: "<?php echo route('charts.'.'months_chart'); ?>",
     hooks:new ChartisanHooks()
            .beginAtZero()
            .responsive()
           .colors()
           .legend({position:"top"})
           .datasets([{type:"bar", 
           label:"Date(MM-DAY-YEAR)",
           borderColor:"red",
           backgroundColor:"red",
           hoverBackgroundColor:"yellow",
           barPercentage: 0.6,
           minBarLength: 2,
           axis:true
           }])
           
   });
 </script>

 <script>
   
 </script>
    
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katende/Desktop/final-project/resources/views/chart/monthchart.blade.php ENDPATH**/ ?>